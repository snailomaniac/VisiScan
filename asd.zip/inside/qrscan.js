function startScanner() {
    let qrScanner = new Html5Qrcode("qrReader");
    let lastScannedText = null;
    let debounceTimeout = null;

    qrScanner.start(
        { facingMode: "environment" },
        {
            fps: 60, // Increase fps for faster scanning
            qrbox: 300 // Adjust qrbox size as needed
        },
        (decodedText) => {
            if (decodedText !== lastScannedText) {
                lastScannedText = decodedText;

                // Debounce mechanism to limit database updates
                if (debounceTimeout) {
                    clearTimeout(debounceTimeout);
                }
                debounceTimeout = setTimeout(() => {
                    document.getElementById("qrResult").innerText = "Scanned: " + decodedText;
                    console.log("New QR scanned:", decodedText);
                    onScanSuccess(decodedText, qrScanner);
                }, 1000); // 1 second delay before processing the scan
            }
        },
        (errorMessage) => {
            console.error("QR scanning error:", errorMessage);
        }
    ).catch(err => {
        console.error("Failed to start QR scanner.", err);
    });
}

function onScanSuccess(decodedText, qrScanner) {
    // Display the scanned result
    document.getElementById("qrResult").innerText = `Scanned: ${decodedText}`;

    // Stop the scanner to prevent multiple scans
    qrScanner.stop().then(() => {
        console.log("QR scanner stopped.");

        // Send the scanned data to the server to log it
        fetch('log_scan.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: decodedText })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Scan logged successfully');
                
                // Display user details if available
                if (data.user) {
                    const userInfo = document.getElementById("qrUserInfo");
                    userInfo.innerHTML = `
                        <div class="user-details">
                            <p><strong>Name:</strong> ${data.user.first_name} ${data.user.last_name}</p>
                            <p><strong>Phone:</strong> ${data.user.phone}</p>
                            <p><strong>Address:</strong> ${data.user.address}</p>
                        </div>
                    `;
                    userInfo.style.display = 'block';
                }
                
                // Add button to scan again instead of auto-refresh
                const container = document.querySelector('.container');
                const scanAgainBtn = document.createElement('button');
                scanAgainBtn.innerText = 'Scan Again';
                scanAgainBtn.className = 'scan-again-btn';
                scanAgainBtn.onclick = function() {
                    location.reload();
                };
                container.appendChild(scanAgainBtn);
                
                // No auto-refresh to allow admin to view the details
                // setTimeout(() => {
                //     location.reload();
                // }, 1000);
            } else {
                console.error('Failed to log scan');
                document.getElementById("qrUserInfo").innerText = 'Failed to log scan: ' + (data.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById("qrUserInfo").innerText = 'Error processing scan';
        });
    }).catch(err => {
        console.error("Failed to stop QR scanner.", err);
    });
}

// Start the scanner when the page loads
window.addEventListener('load', startScanner);
