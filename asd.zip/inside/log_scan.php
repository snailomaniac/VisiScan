<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$name = $data['name'];
$username = $_SESSION['username'];

// Check if the logged-in user is admin
if ($username == 'admin') {
    // Extract the actual username from the scanned data
    $scannedUsername = $name; // Assuming the scanned data contains the username
} else {
    $scannedUsername = $username;
}

$mysqli = new mysqli('localhost', 'root', '', 'visiscan_db');

if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Get the current date
$current_date = date('Y-m-d');

// Check if the user has already checked in today
$stmt = $mysqli->prepare("SELECT * FROM logs WHERE username = ? AND scan_date = ?");
$stmt->bind_param("ss", $scannedUsername, $current_date);
$stmt->execute();
$result = $stmt->get_result();

// In log_scan.php, modify the end of the file where responses are sent
if ($result->num_rows > 0) {
    // User has already checked in, update the check-out time
    $stmt = $mysqli->prepare("UPDATE logs SET check_out = NOW() WHERE username = ? AND scan_date = ?");
    $stmt->bind_param("ss", $scannedUsername, $current_date);
    $stmt->execute();
    
    // Get user details
    $userStmt = $mysqli->prepare("SELECT id, first_name, last_name, email, phone, address, birth_date FROM users WHERE username = ?");
    $userStmt->bind_param("s", $scannedUsername);
    $userStmt->execute();
    $userResult = $userStmt->get_result();
    $userData = $userResult->fetch_assoc();
    
    echo json_encode(['success' => true, 'message' => 'Check-Out logged!', 'user' => $userData]);
    $userStmt->close();
} else {
    // User has not checked in, insert a new record with check-in time
    $stmt = $mysqli->prepare("INSERT INTO logs (user_id, username, scan_date, check_in) VALUES ((SELECT id FROM users WHERE username = ?), ?, NOW(), NOW())");
    $stmt->bind_param("ss", $scannedUsername, $scannedUsername);
    $stmt->execute();
    
    // Get user details
    $userStmt = $mysqli->prepare("SELECT id, first_name, last_name, email, phone, address, birth_date FROM users WHERE username = ?");
    $userStmt->bind_param("s", $scannedUsername);
    $userStmt->execute();
    $userResult = $userStmt->get_result();
    $userData = $userResult->fetch_assoc();
    
    echo json_encode(['success' => true, 'message' => 'Check-In logged!', 'user' => $userData]);
    $userStmt->close();
}

$stmt->close();
$mysqli->close();
?>