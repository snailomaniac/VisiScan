<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['username']) || $_SESSION['username'] != 'admin') {
    header("Location: ../form/login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "visiscan_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM logs";
$result = $conn->query($sql);
?>
<!DOCTYPE html> 
<html lang="en"> 
    <head> 
        <meta charset="UTF-8"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title> Admin Log | VisiScan</title>
        <link rel="stylesheet" href="adminlog.css">
        <link rel="stylesheet" href="../style.css"/> 
    </head>
    <body>
        <hamburger-menu-admin></hamburger-menu-admin>
        <header-registered-admin></header-registered-admin>
        <main>
            <div class="logtable">
                <h1>Visitors Logs</h1>
                <input type="text" id="logSearch" placeholder="Search Logs..." onkeyup="filterLogs()">
                <table cellspacing="0px" cellpadding="16px">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Address</th>
                            <th>Birthdate</th>
                            <th>Date</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                        </tr>
                    </thead>
                    <tbody id="logTable">
                        <?php if ($result->num_rows > 0): ?>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                    <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><?php echo htmlspecialchars($row['address']); ?></td>
                                    <td><?php echo htmlspecialchars($row['birthdate']); ?></td>
                                    <td><?php echo htmlspecialchars($row['date']); ?></td>
                                    <td><?php echo htmlspecialchars($row['check_in']); ?></td>
                                    <td><?php echo htmlspecialchars($row['check_out']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan='10'>No logs found</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
        <footer-registered></footer-registered>
    </body>
    <script>
        function filterLogs() {
            let input = document.getElementById("logSearch").value.toLowerCase();
            let rows = document.querySelectorAll("#logTable tr");
            
            rows.forEach(row => {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(input) ? "" : "none";
            });
        }
    </script>
    <script src="admin_log.js"></script>
    <script src="../overlay.js"></script>   
</html>
<?php
$conn->close();
?>