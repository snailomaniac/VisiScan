-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 04:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `visiscan_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `scan_date` date NOT NULL,
  `check_in` time NOT NULL,
  `check_out` time DEFAULT NULL,
  `reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `username`, `scan_date`, `check_in`, `check_out`, `reason`) VALUES
(1, 1, 'em', '2025-03-23', '06:24:58', NULL, 'Card Distribution'),
(2, 2, 'Raff', '2025-03-24', '07:51:09', NULL, 'makiki cr'),
(3, 3, 'kate', '2025-03-24', '08:12:32', '08:12:56', 'Visiting the school facility'),
(4, 3, 'kate', '2025-03-24', '08:15:01', '08:15:10', 'may putok si montas'),
(5, 4, 'coco', '2025-03-24', '08:19:48', '08:22:54', 'registrar'),
(7, 6, 'MarkGeraldPacun', '2025-03-24', '08:50:00', '08:50:40', 'Tangina mo dexter'),
(8, 6, 'MarkGeraldPacun', '2025-03-24', '08:50:48', '08:51:03', 'Tangina mo dexter'),
(9, 8, 'Yuu123', '2025-03-24', '13:49:40', '13:50:06', 'Card Report'),
(10, 9, 'Ricko', '2025-03-24', '14:34:50', '14:35:17', 'Parents Meeting');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT 'default_profile_picture.png',
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birth_date` date NOT NULL,
  `account_status` enum('true','pending','false','restricted') NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `profile_picture`, `first_name`, `last_name`, `email`, `phone`, `address`, `birth_date`, `account_status`) VALUES
(1, 'em', '$2y$10$3UuQXLuBMWiLlM.svnr8auDizJtOasXjNdFQFWYcNrWhhen0PhPxy', '../profiles/em_profile.png', 'James Marku', 'Alarcon', 'jamesmarkugame@gmail.com', '09635469788', '#12 vigro batasan quezon city', '2006-02-08', 'restricted'),
(2, 'Raff', '$2y$10$pZQ9EpHlYkcPiwQIPOB6KO.Z4of3NNYbFQfULwHRvvAS6pzUhAT6e', '../profiles/Raff_profile.png', 'Rafael', 'Montas', 'Montas@gmail.com', '09757384467', 'Brgy Holy Spirit 1234', '2006-11-13', 'true'),
(3, 'kate', '$2y$10$0e5enoEPbCH86hnukY3tMOsz/wDNcOBCRlYaDz.uiPY6YEvvgkajG', '../profiles/kate_profile.png', 'Kate', 'Escala', 'pamelacacayan@gmail.com', '09271323935', '#89 Virgo st. Bulacan Village Quezon City', '2007-06-27', 'true'),
(4, 'coco', '$2y$10$.PDE6iY3Ak.052HYpTbd1O6ZPMUgDfzXy9nSzOwUAFa/.7yEfDnGG', '../profiles/coco_profile.png', 'coco', 'pogi', 'coco@gmail.com', '98908278968', 'cc', '2025-03-26', 'true'),
(6, 'MarkGeraldPacun', '$2y$10$eTpTp5IlKDUHBTwactmEnuyoqlWPrROzZKsXXW0k4jZ9qbGqbyAjG', '../profiles/MarkGeraldPacun_profile.png', 'Mark', 'Pacun', 'markgpacun@gmail.com', '09937014898', 'blk 7 lot 11 phs 10', '2007-02-16', 'true'),
(7, 'asd', '$2y$10$SC5JX1eINofuZEVDRH3JhO9yq4SkID9oHyzWtByMjR0MB0ia6nzpG', 'default_profile_picture.png', 'asd', 'asd', 'asd@gmail.com', '09090909091', '', '0000-00-00', 'false'),
(8, 'Yuu123', '$2y$10$C6gK7hPo8GayGBE73n9T/esMdEYxARegeoVe5/gxzfkdo7lPz3HtC', '../profiles/Yuu123_profile.png', 'Joseph Justin', 'Machica', 'josephmachica@gmail.com', '09614510059', 'blk 18 lot 24 Kalap subdivision, Novaliches, Quezon City', '2007-04-20', 'true'),
(9, 'Ricko', '$2y$10$NL8vhx0NLzAsXTiNi7MGqerCD3tPFf9bkMndMQwWt13yPkm1FbkSm', '../profiles/Ricko_profile.png', 'Rick', 'Limbaga', 'ricklimbaga@gmail.com', '09923127521', '#3 Kalayaan D st. brgy. batasan hills QC', '0007-02-08', 'true');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_logs_users` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username_2` (`username`,`email`),
  ADD KEY `id` (`id`,`username`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `fk_logs_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
