-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2025 at 06:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `visiscan_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `scan_date` date NOT NULL,
  `check_in` time NOT NULL,
  `check_out` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `username`, `scan_date`, `check_in`, `check_out`) VALUES
(1, 11, 'lex', '2025-03-05', '00:59:18', NULL),
(4, 11, 'lex', '2025-03-05', '01:02:15', NULL),
(6, 11, 'lex', '2025-03-05', '06:10:11', NULL),
(7, 12, 'hatdog', '2025-03-05', '06:30:32', NULL),
(8, 13, 'asher', '2025-03-05', '09:16:44', NULL),
(9, 10, 'em', '2025-03-08', '22:32:36', '22:33:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT '''default_profile_picture.png''',
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birth_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `profile_picture`, `first_name`, `last_name`, `email`, `phone`, `address`, `birth_date`) VALUES
(10, 'em', '$2y$10$IWKTkiXrnOJSTY8lynAG9.57BEt.kFsxm8tDqKbBIjQTwk8fp3Hey', 'default_profile_picture.png', 'James Marku', 'Alarcon', 'jm@gmail.com', '0999999999', 'batasan hill quezon city', '2006-02-08'),
(11, 'lex', '$2y$10$9TkeMwsaRp3hfdJfRWUHjedjkR1unvcy3CZaXjzyf6mWWz34A.m02', 'default_profile_picture.png', 'Alex', 'Alarcon', 'alexalarcon@gmail.com', '09999999999', 'quezon city', '2000-04-09'),
(12, 'hatdog', '$2y$10$RX24itO8WLfskSts7sBSj.u4y3DEXrEbaCyP3QPiBu4DtLGr28g4S', 'default_profile_picture.png', 'maku', 'james', 'makujames@gmail.com', '09112345617', '#12 vigro batasan quezon city', '2007-06-27'),
(13, 'asher', '$2y$10$xy51aYv0FfFwEjglfxOg3eMPlSFxbyAljk0f1OTEWkl5e0gIjWpdu', 'default_profile_picture.png', 'neil', 'katug', 'katug@gmail.com', '0967362821', 'caloocan city', '2025-03-05'),
(16, 'asd', '$2y$10$QRqczB7mlEIc0uBRgVrU6emvc7aUR9aV.aBTX5sSooUJHcoQwrvWy', 'default_profile_picture.png', 'asd', 'asd', 'asd@gmail.com', '090909090909', 'asd', '0006-02-08'),
(20, 'qwe', '$2y$10$R/l7pmCavIGfgeyfWBXuge5SBPY1aTY.2xUbIDHzXZ1rFnNjZ3eTO', 'default_profile_picture.png', 'qwe', 'qwe', 'qwe@gmail.com', '09090909', 'asd', '2025-03-19'),
(21, 'zxc', '$2y$10$R2vcxnX8nEUDNX4LVHThWONOEuaNs3iPaqCy0Mfa38wcIDjGUptOW', 'default_profile_picture.png', 'zxc', 'zxc', 'zxc@gmail.com', '0909090909', 'adasd', '2025-03-20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username_2` (`username`,`email`),
  ADD KEY `id` (`id`,`username`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
