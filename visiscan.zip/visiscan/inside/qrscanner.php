<!DOCTYPE html> 
<html lang="en"> 
    <head> 
        <meta charset="UTF-8"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title> Scanner | VisiScan</title>         
        <link rel="stylesheet" href="qrscanner.css"/> 
        <link rel="stylesheet" href="../style.css"/> 
    </head>     
    <body>
        <?php
            session_start();
        ?>
        <hamburger-menu></hamburger-menu>         
        <header-registered></header-registered>         
        <article>
            <div class="container">
                <div id="qrReader" class="camera"></div>
                <p id="qrResult" class="text">Scan a QR Code</p>
            </div>
        </article> 
        <footer-registered></footer-registered>         
    </body>
    <!--Scanner library-->
    <script src="html5-qrcode.js"></script>
    <script src="../overlay.js"></script>
    <script src="qrscan.js"></script>
</html>