function startScanner() {
    let qrScanner = new Html5Qrcode("qrReader");

    qrScanner.start(
        { facingMode: "environment" },
        {
            fps: 10,
            qrbox: 250
        },
        (decodedText) => {
            document.getElementById("qrResult").innerText = "Scanned: " + decodedText;

            // to Prevent from scanning same multiple qrcode
            if (window.lastScannedCode !== decodedText) {
                window.lastScannedCode = decodedText;
                console.log("New QR scanned:", decodedText);
                onScanSuccess(decodedText);
            }
        },
        (errorMessage) => {}
    );
}

function onScanSuccess(decodedText, decodedResult) {
    // Display the scanned result
    document.getElementById("qrResult").innerText = `Scanned: ${decodedText}`;

    // Send the scanned data to the server to log it
    fetch('log_scan.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: decodedText })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Scan logged successfully');
        } else {
            console.error('Failed to log scan');
        }
    })
    .catch(error => console.error('Error:', error));
}

let html5QrcodeScanner = new Html5QrcodeScanner(
    "qrReader", { fps: 10, qrbox: 250 });
html5QrcodeScanner.render(onScanSuccess);
