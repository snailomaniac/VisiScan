function startScanner() {
    let qrScanner = new Html5Qrcode("qrReader");
    let lastScannedText = null;
    let debounceTimeout = null;

    qrScanner.start(
        { facingMode: "environment" },
        {
            fps: 30, // Increase fps for faster scanning
            qrbox: 250
        },
        (decodedText) => {
            if (decodedText !== lastScannedText) {
                lastScannedText = decodedText;

                // Debounce mechanism to limit database updates
                if (debounceTimeout) {
                    clearTimeout(debounceTimeout);
                }
                debounceTimeout = setTimeout(() => {
                    document.getElementById("qrResult").innerText = "Scanned: " + decodedText;
                    console.log("New QR scanned:", decodedText);
                    onScanSuccess(decodedText, qrScanner);
                }, 1000); // 1 second delay before processing the scan
            }
        },
        (errorMessage) => {
            console.error("QR scanning error:", errorMessage);
        }
    ).catch(err => {
        console.error("Failed to start QR scanner.", err);
    });
}

function onScanSuccess(decodedText, qrScanner) {
    // Display the scanned result
    document.getElementById("qrResult").innerText = `Scanned: ${decodedText}`;

    // Stop the scanner to prevent multiple scans
    qrScanner.stop().then(() => {
        console.log("QR scanner stopped.");

        // Send the scanned data to the server to log it
        fetch('log_scan.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: decodedText })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Scan logged successfully');
                // Refresh the page after a successful scan
                setTimeout(() => {
                    location.reload();
                }, 1000); // 1 second delay before refreshing
            } else {
                console.error('Failed to log scan');
            }
        })
        .catch(error => console.error('Error:', error));
    }).catch(err => {
        console.error("Failed to stop QR scanner.", err);
    });
}

// Start the scanner when the page loads
window.addEventListener('load', startScanner);
