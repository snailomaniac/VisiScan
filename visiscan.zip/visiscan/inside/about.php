<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>About | VisiScan</title>
        <link rel="stylesheet" href="../style.css">
        <link rel="stylesheet" href="about.css">
    </head>
    <body>
        <hamburger-menu></hamburger-menu>
        <header-registered></header-registered>
        <main>
            <div class="container">
                <h2>VisiScan Team</h2>
                <div class="cards">
                    <img src="../assets/janessa.jpg" alt="janessa">
                    <p>Janessa Genne Baisa</p>
                    <h5>Project Manager</h5>
                </div>
                <div class="cards">
                    <img src="../assets/marku.jpg" alt="em">
                    <p>James Marku Alarcon</p>
                    <h5>Programmer</h5>
                </div>
                <div class="cards">
                    <img src="../assets/placeholder.png" alt="rick">
                    <p>Rick Limbaga</p>
                    <h5>System Analyst</h5>
                </div>
                <div class="cards">
                    <img src="../assets/rafael.jpg" alt="raf">
                    <p>Rafael Montas</p>
                    <h5>Debugger</h5>
                </div><br>
                <div class="cards">
                    <img src="../assets/sirchard.jpg" alt="raf">
                    <p>Richard Zabala</p>
                    <h5>Adviser</h5>
                </div>
                <div class="cards">
                    <img src="../assets/maamjaja.jpg" alt="raf">
                    <p>Jay Bilog Cabalce</p>
                    <h5>Research Teacher</h5>
                </div>
            </div>
        </main>
        <footer-registered></footer-registered>
    </body>
    <script src="../overlay.js"></script>
</html>