<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Content-Type: application/json');
    die(json_encode(["error" => "Not logged in"]));
}
$username = $_SESSION['username'];

$conn = new mysqli('localhost', 'root', '', 'visiscan_db');

if ($conn->connect_error) {
    die(json_encode(["error" => "Database Connection Failed"]));
}

header('Content-Type: application/json');

// Fetch logs filtered by username
$sql = "SELECT username, scan_date, TIME_FORMAT(check_in, '%h:%i %p') AS check_in, 
        TIME_FORMAT(check_out, '%h:%i %p') AS check_out, reason 
        FROM logs WHERE username = ? ORDER BY scan_date DESC";

// Use prepared statement to prevent SQL injection
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

$logs = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $logs[] = [
            "username" => $row["username"],
            "scan_date" => $row["scan_date"],
            "check_in" => $row["check_in"],
            "check_out" => $row["check_out"] ?? "--",
            "reason" => !empty($row["reason"]) ? htmlspecialchars($row["reason"]) : "--"
        ];
    }
}

// Close connection
$stmt->close();
$conn->close();

// Output JSON
echo json_encode($logs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>