// =============== !! Important for the buttons to work !!  =============== //
window.navigateTo = function(url) {
    window.location.href = url;
};

// =============== Hamburger menu only Inside  =============== //
class NavigationHamburgerMenu extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <div class="off-screen-menu" id="menu">
            <ul>
                <li><button class="menu-btn" onclick="navigateTo('home.php')">Home</button></li>
                <li><button class="menu-btn" onclick="navigateTo('qrcode.php')">QR Code</button></li>
                <li><button class="menu-btn" onclick="navigateTo('log.php')">Logs</button></li>
                <li><button class="menu-btn" onclick="navigateTo('about.html')" /disabled>About</button></li>
            </ul>
        </div>
        `;
    }
}

customElements.define('hamburger-menu', NavigationHamburgerMenu);

// ===============  Outside  =============== //
class HeaderGuest extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <nav class="navoutside">
            <button id="homeButton" class="unreg" onclick="navigateTo('../index.html')">Home</button>
            <button id="aboutButton" class="unreg" onclick="navigateTo('outside/about.html')">About</button>
        </nav>
        `;

        const currentPath = window.location.pathname;
        if (currentPath.includes('index.html')) {
            const homeButton = document.getElementById('homeButton');
            homeButton.disabled = true;
            homeButton.classList.add('navBarUnregOn');
        } else if (currentPath.includes('about.html')) {
            const aboutButton = document.getElementById('aboutButton');
            aboutButton.disabled = true;
            aboutButton.classList.add('navBarUnregOn');
        }
    }
}

class FooterGuest extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <footer>
            <hr>
            <div class="ul-footer-container">
                <ul>
                    <li><h3>Navigate</h3></li>
                    <li><p><a href="index.html">Home</a></p></li>
                    <li><p><a href="indexabout.html">About</a></p></li>
                </ul>
                <ul>
                    <li><h3>Follow</h3></li>
                    <li><p>asd</p></li>
                </ul>
                <ul>
                    <li><h3>Contact</h3></li>
                    <li><p>asd</p></li>
                </ul>
                <ul>
                    <li><h3>About</h3></li>
                    <li><p>asd</p></li>
                </ul>
            </div>
            <div class="end-footer-container">
                <h6>All Rights Reserved.</h6>
                <h6>Safe Secured Students</h6>
                <h6>2024, Made from Lagro High School</h6>
            </div>
        </footer>
        `;
    }
}

customElements.define('header-guest', HeaderGuest);
customElements.define('footer-guest', FooterGuest);

// ===============  Inside  =============== //
class HeaderRegistered extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <nav class="navinside">
            <div class="navleft">
                <img src="../assets/logo.png" alt="logo" class="logonav">
                <p>Lagro High School<br>VisiScan</p>
            </div>
            <div class="navright">
                <button class="nav-menu-btn" id="menuBtn" onclick="toggleMenu()"><img src="../assets/icons/menu.svg" alt="Menu"></button>
                <button class="profile-btn" onclick="navigateTo('viewprofile.php')">
                    <img src="../assets/default_profile_picture.png" alt="Profile" class="profile-pic">
                    <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                </button>
                <button class="nav-menu-btn" id="logoutBtn" onclick="logout()"><img src='../assets/icons/log-out.svg' alt='Logout'><h3>Logout</h3></button>
            </div>
        </nav>
        `;
    }
}

class FooterRegistered extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <footer>
            <hr>
            <div class="ul-footer-container">
                <ul>
                    <li><h3>Navigate</h3></li>
                    <li><p><a href="../index.html">Index/Home</a></p></li>
                    <li><p><a href="../indexabout.html">Index/About</a></p></li>
                    <li><p><a href="home.php">Home</a></p></li>
                    <li><p><a href="qrcode.html">Qr Code</a></p></li>
                    <li><p><a href="../#">none</a></p></li>
                    <li><p><a href="../#">none</a></p></li>
                </ul>
                <ul>
                    <li><h3>Follow</h3></li>
                    <li><p>asd</p></li>
                </ul>
                <ul>
                    <li><h3>Contact</h3></li>
                    <li><p>asd</p></li>
                </ul>
                <ul>
                    <li><h3>About</h3></li>
                    <li><p>asd</p></li>
                </ul>
            </div>
            <div class="end-footer-container">
                <h6>All Rights Reserved.</h6>
                <h6>Safe Secured Students</h6>
                <h6>2024, Made from Lagro High School</h6>
            </div>
        </footer>
        `;
    }
}

customElements.define('header-registered', HeaderRegistered);
customElements.define('footer-registered', FooterRegistered);

// ===============  Admin  =============== //
class HeaderRegisteredAdmin extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <nav class="navinside">
            <div class="navleft">
                <img src="../assets/logo.png" alt="logo" class="logonav">
                <p>Lagro High School<br>VisiScan</p>
            </div>
            <div class="navright">
                <button class="nav-menu-btn" id="menuBtnAdmin" onclick="toggleMenuAdmin()"><img src="../assets/icons/menu.svg" alt="Menu"></button>
                <button class="nav-menu-btn" id="logoutBtn" onclick="logout()"><img src='../assets/icons/log-out.svg' alt='Logout'><h3>Logout</h3></button>
            </div>
        </nav>
        `;
    }
}

class NavigationHamburgerMenuAdmin extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <div class="off-screen-menu" id="menuAdmin">
            <ul>
                <li><button class="menu-btn" onclick="navigateTo('admin.php')">Admin Panel</button></li>
                <li><button class="menu-btn" onclick="navigateTo('qrscanner.php')">QR Scanner</button></li>
                <li><button class="menu-btn" onclick="navigateTo('adminlog.php')">Entry Logs</button></li>
                <li><button class="menu-btn" onclick="navigateTo('manageaccount.php')">Account Management</button></li>
                <li><button class="menu-btn" onclick="navigateTo('about.html')" /disabled>About</button></li>
            </ul>
        </div>
        `;
    }
}

customElements.define('header-registered-admin', HeaderRegisteredAdmin);
customElements.define('hamburger-menu-admin', NavigationHamburgerMenuAdmin);

// ===============  Functions  =============== //
function toggleMenu() {
    let menu = document.getElementById("menu");
    let menuBtn = document.getElementById("menuBtn");

    if (menu.classList.contains("open")) {
        menu.classList.remove("open");
        menuBtn.classList.remove("opened");
    } else {
        menu.classList.add("open");
        menuBtn.classList.add("opened");
    }
}

function toggleMenuAdmin() {
    let menuAdmin = document.getElementById("menuAdmin");
    let menuBtnAdmin = document.getElementById("menuBtnAdmin");

    if (menuAdmin.classList.contains("open")) {
        menuAdmin.classList.remove("open");
        menuBtnAdmin.classList.remove("opened");
    } else {
        menuAdmin.classList.add("open");
        menuBtnAdmin.classList.add("opened");
    }
}

function logout() {
    window.location.href = '../form/logout.php';
}
