<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: ../index.html");
        exit();
    }

    $username = $_SESSION['username'];
?>
<!DOCTYPE html> 
<html lang="en"> 
    <head> 
        <meta charset="UTF-8"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title> My Logs | VisiScan</title>         
        <link rel="stylesheet" href="log.css"/> 
        <link rel="stylesheet" href="../style.css"/> 
    </head>
    <body>
        <hamburger-menu></hamburger-menu>
        <header-registered></header-registered>
        <article>
            <div class="logtable">
                <h1 style="text-align: center;">Scanned Logs</h1>
                <p><strong>User: </strong><?php echo htmlspecialchars($username)?></p>
                <table cellspacing="0px" cellpadding="16px">
                    <thead >
                        <tr>
                            <th>Date</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                        </tr>
                    </thead>
                    <tbody id="logTable"></tbody>
                </table>
            </div>
        </article>
        <footer-registered></footer-registered>
    </body>
    <script src="log.js"></script>
    <script src="../overlay.js"></script>   
</html>
