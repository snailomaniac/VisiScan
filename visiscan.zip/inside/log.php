<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: ../form/login.php");
        exit();
    }
    $username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Logs | VisiScan</title>
    <link rel="stylesheet" href="log.css"/>
    <link rel="stylesheet" href="../style.css"/>
    <style>
        .search-container {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-container input {
            padding: 10px;
            width: 100%;
            max-width: 400px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <hamburger-menu></hamburger-menu>
    <header-registered></header-registered>
    <div class="logtable">
        <h1 style="text-align: center;">Scanned Logs</h1>
        <p><strong>User: </strong><?php echo htmlspecialchars($username)?></p>
        <div class="search-container">
            <input type="text" id="logSearch" placeholder="Search Logs..." onkeyup="filterLogs()">
        </div>
        <table cellspacing="0px" cellpadding="16px">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Check In</th>
                    <th>Check Out</th>
                </tr>
            </thead>
            <tbody id="logTable">
                <?php 
                    // Simulated database logs (Replace this with actual DB query)
                    $logs = [
                        ['date' => '2025-03-01', 'checkin' => '08:00 AM', 'checkout' => '05:00 PM'],
                        ['date' => '2025-03-02', 'checkin' => '09:15 AM', 'checkout' => '06:00 PM'],
                        ['date' => '2025-03-03', 'checkin' => '07:30 AM', 'checkout' => '04:45 PM'],
                    ];
                    foreach ($logs as $log) {
                        echo "<tr><td>" . htmlspecialchars($log['date']) . "</td>";
                        echo "<td>" . htmlspecialchars($log['checkin']) . "</td>";
                        echo "<td>" . htmlspecialchars($log['checkout']) . "</td></tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
    <footer-registered></footer-registered>
    <script>
        function filterLogs() {
            let input = document.getElementById("logSearch");
            let filter = input.value.toLowerCase();
            let table = document.getElementById("logTable");
            let rows = table.getElementsByTagName("tr");
            
            for (let i = 0; i < rows.length; i++) {
                let rowText = rows[i].textContent || rows[i].innerText;
                rows[i].style.display = rowText.toLowerCase().includes(filter) ? "" : "none";
            }
        }
    </script>
    <script src="log.js"></script>
    <script src="../overlay.js"></script>  
</body>
</html>
