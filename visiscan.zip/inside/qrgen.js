function generateQR() {
    let username = document.getElementById("username").value.trim();

    if (!username) {
        alert("User session not found. Please log in.");
        return;
    }

    let qrData = username;
    let qrImageGen = document.getElementById("qrImageGen");

    qrImageGen.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrData)}`;
}
