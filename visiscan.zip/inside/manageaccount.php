<?php
    session_start();
    if (!isset($_SESSION['username']) || $_SESSION['username'] != 'admin') {
        header("Location: ../form/login.php");
        exit();
    }

    $conn = new mysqli("localhost", "root", "", "visiscan_db");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $search = "";
    if (isset($_POST['search'])) {
        $search = $conn->real_escape_string($_POST['search']);
        $sql = "SELECT id, username, first_name, last_name, email, phone FROM users 
                WHERE username LIKE '%$search%' 
                OR first_name LIKE '%$search%' 
                OR last_name LIKE '%$search%' 
                OR phone LIKE '%$search%'";
    } else {
        $sql = "SELECT id, username, first_name, last_name, email, phone FROM users";
    }
    $result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Account | VisiScan</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="../style.css">
    <style>
        .button-container { display: flex; gap: 5px; }
        .button-container button {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .view-button { background-color: #4CAF50; color: white; }
        .delete-button { background-color: #f44336; color: white; }
        .add-button { background-color: #008CBA; color: white; }
        .search-container { margin-bottom: 10px; text-align: center; }
        .search-container input {
            padding: 10px;
            width: 100%;
            max-width: 400px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <hamburger-menu-admin></hamburger-menu-admin>
    <header-registered-admin></header-registered-admin>
    <div class="container">
        <h1>Account Management</h1>
        <div class="search-container">
            <input type="text" id="accountSearch" placeholder="Search accounts..." onkeyup="filterAccounts()">
        </div>
        <button class="add-button">Add Account</button>
        <table cellspacing="0px" cellpadding="16px">
            <thead>
                <tr>
                    <th width="0px">ID</th>
                    <th width="60px">Username</th>
                    <th width="200px">Name</th>
                    <th width="130px">Contact</th>
                    <th width="150px">Manage</th>
                </tr>
            </thead>
            <tbody id="accountTable">
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['phone']); ?></td>
                            <td class='button-container'>
                                <button class='delete-button'>Delete</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan='5'>No users found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <footer-registered></footer-registered>
    <script src="../overlay.js"></script>
    <script>
        function filterAccounts() {
            let input = document.getElementById("accountSearch");
            let filter = input.value.toLowerCase();
            let table = document.getElementById("accountTable");
            let rows = table.getElementsByTagName("tr");
            
            for (let i = 0; i < rows.length; i++) {
                let rowText = rows[i].textContent || rows[i].innerText;
                rows[i].style.display = rowText.toLowerCase().includes(filter) ? "" : "none";
            }
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>