<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: ../index.html");
    }

    $username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code | VisiScan</title>
    <link rel="stylesheet" href="qrcode.css"/>
    <link rel="stylesheet" href="../style.css"/>
    <script src="qrgen.js" defer></script>
</head>
<body>
    <hamburger-menu></hamburger-menu>
    <header-registered></header-registered>
    <article>
        <div class="main-container">
            <input type="hidden" id="username" value="<?php echo htmlspecialchars($username); ?>">
            <div class="qrimgholder">
                <img src="" id="qrImageGen" alt="Your QR Code">
            </div>
            <div class="text-warning">
                <h3>Important!</h3>
                <p>Any actions related to this QR Code
                   are linked to your name, and any
                   occurrences associated with it
                   during your consultation will be
                   directly tied to your information.
                   Please do not share the QR Code to
                   avoid any potential issues.</p>
            </div>
            <button class="genbtn" onclick="generateQR()" style="grid-area:2 / 1 / 3 / 3;">Your QR Code</button>
        </div>
    </article>
    <footer-registered></footer-registered>
    <script src="../overlay.js"></script>
</body>
</html>