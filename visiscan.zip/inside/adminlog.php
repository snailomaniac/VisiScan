<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['username']) || $_SESSION['username'] != 'admin') {
    header("Location: ../inside/home.php");
    exit();
}
?>
<!DOCTYPE html> 
<html lang="en"> 
    <head> 
        <meta charset="UTF-8"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title> Admin Log | VisiScan</title>
        <link rel="stylesheet" href="adminlog.css">
        <link rel="stylesheet" href="../style.css"/> 
    </head>
    <body>
        <hamburger-menu-admin></hamburger-menu-admin>
        <header-registered-admin></header-registered-admin>
        <article>
            <div class="logtable">
            <h1>Visitors Logs</h1>
                <table cellspacing="0px" cellpadding="16px">
                    <thead>
                        <tr>
                            <th width="0px">Username</th>
                            <th width="60px">First Name</th>
                            <th width="60px">Last Name</th>
                            <th width="100px">Email</th>
                            <th width="50px">Contact</th>
                            <th width="100px">Address</th>
                            <th width="0px">Birthdate</th>
                            <th width="100px">Date</th>
                            <th width="20px">Check In</th>
                            <th width="20px">Check Out</th>
                        </tr>
                    </thead>
                    <tbody id="logTable"></tbody>
                </table>
            </div>
        </article>
        <footer-registered></footer-registered>
    </body>
    <script src="admin_log.js"></script>
    <script src="../overlay.js"></script>   
</html>
