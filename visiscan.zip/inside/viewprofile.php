<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../form/login.php");
    exit();
}

$username = $_SESSION['username'];
$conn = new mysqli("localhost", "root", "", "visiscan_db");

// Get user info
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Get profile picture
$profile_picture = "../profiles/";
$profile_picture .= empty($user['profile_picture']) ? "default_profile_picture.png" : $user['profile_picture'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | VisiScan</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <hamburger-menu></hamburger-menu>
    <header-registered></header-registered>

    <div class="container">
        <h1>Your Profile</h1>

        <!-- Profile Picture Upload -->
        <form method="post" enctype="multipart/form-data">
            <img src="<?php echo $profile_picture; ?>" alt="Profile Picture" width="150">
            <br>
            <input type="file" name="profile_picture">
            <input type="submit" value="Upload Picture">
        </form>

        <!-- User Info Table -->
        <table>
            <thead>
                <tr>
                    <th>Profile Picture</th>
                    <th>Username</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><img src="<?php echo htmlspecialchars($profile_picture); ?>" alt="Your Picture" width="100"></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($user['phone']); ?></td>
                    <td><?php echo htmlspecialchars($user['address']); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <footer-registered></footer-registered>
</body>
<script src="../overlay.js"></script>
</html>
<?php $conn->close(); ?>
