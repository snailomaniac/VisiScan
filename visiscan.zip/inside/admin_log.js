function loadAdminLogs() {
    fetch("admin_fetch_logs.php")
    .then(response => response.json())
    .then(data => {
        let tableBody = document.getElementById("logTable");
        tableBody.innerHTML = "";
        data.forEach(log => {
            let formattedDate = new Date(log.scan_date).toLocaleDateString('en-US', { 
                weekday: 'short', 
                month: 'short', 
                day: 'numeric', 
                year: 'numeric' 
            });

            let row = `<tr>
                <td>${log.username}</td>
                <td>${log.first_name}</td>
                <td>${log.last_name}</td>
                <td>${log.email}</td>
                <td>${log.phone}</td>
                <td>${log.address}</td>
                <td>${log.birth_date}</td>
                <td>${formattedDate}</td>
                <td>${log.check_in}</td>
                <td>${log.check_out ? log.check_out : '--'}</td>
            </tr>`;
            tableBody.innerHTML += row;
        });
    })
    .catch(error => console.error("Error fetching logs:", error));
}

loadAdminLogs();
setInterval(loadAdminLogs, 5000);