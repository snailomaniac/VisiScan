<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['username'] != 'admin') {
    header("Location: ../../index.php");
    exit();
}

$mysqli = new mysqli('localhost', 'root', '', 'visiscan_db');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$sql = "SELECT users.username, users.first_name, users.last_name, users.email, users.phone, users.address, users.birth_date, logs.scan_date, logs.check_in, logs.check_out 
        FROM logs 
        JOIN users ON logs.user_id = users.id 
        ORDER BY logs.scan_date DESC, logs.check_in DESC";

$result = $mysqli->query($sql);

$logs = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
}

$mysqli->close();

header('Content-Type: application/json');
echo json_encode($logs);
?>