<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$name = $data['name'];
$username = $_SESSION['username'];

$mysqli = new mysqli('localhost', 'root', '', 'visiscan_db');

if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

$stmt = $mysqli->prepare("INSERT INTO logs (user_id, username, scan_date, check_in) VALUES ((SELECT id FROM users WHERE username = ?), ?, NOW(), NOW())");
$stmt->bind_param('ss', $username, $name);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to log scan']);
}

$stmt->close();
$mysqli->close();
?>