<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['username']) || $_SESSION['username'] != 'admin') {
    header("Location: ../inside/home.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page | VisiScan</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <hamburger-menu-admin></hamburger-menu-admin>
    <header-registered-admin></header-registered-admin>
    <article>
        <div class="bigcontainer">
            <div class="container">
                <h1>Welcome, Admin!</h1>
                <!-- Admin content goes here -->
            </div>
        </div>
    </article>
    <footer-registered></footer-registered>
</body>
<script src="../overlay.js"></script>
</html>